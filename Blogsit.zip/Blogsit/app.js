require('dotenv').config()

const express = require("express");
const userRoute = require('./routes/user');
const blogRoute = require('./routes/blog');
const mongoose = require("mongoose");
const cookieParser = require('cookie-parser');

const Blog = require('./models/blog');
const Comment = require('./models/comment');

const path = require('path');
const { checkForAuthenticationCookie } = require("./middlewares/authentication");
const app = express();
const PORT =  process.env.PORT || 8004;

mongoose.connect(process.env.MONGO_URL).then(() => {
    console.log('MongoDB connected');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1); // Exit the application if MongoDB connection fails
});

app.set('view engine', 'ejs');
app.set('views', path.resolve("./views"));

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(checkForAuthenticationCookie('token'));
//added extra for user.local verification do check if any errors occurs
app.use((req, res, next) => {
    res.locals.user = req.user; // or however you manage user authentication
    next();
  });
  
app.use("/users", userRoute);
app.use("/blog", blogRoute);
app.use(express.static(path.resolve("./public")));



app.get("/", async (req, res) => {
    try {
        const allBlogs = await Blog.find({}).sort({ createdAt: -1 }); // Fixed sort method
        res.render("home", {
            user: req.user,
            blogs: allBlogs,
        });
    } catch (error) {
        console.error('Error fetching blogs:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/email', (req, res) => {
    console.log("pending");
    res.send("Email route pending implementation");
});

app.listen(PORT, () => {
    console.log('Server is running on port ' + PORT);
});
